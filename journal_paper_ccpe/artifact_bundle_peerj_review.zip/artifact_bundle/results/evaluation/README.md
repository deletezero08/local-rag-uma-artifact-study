# Evaluation Results

This folder contains machine-readable experiment outputs and failure-analysis artifacts.

## Current Paper-Track Evidence

Use these first when validating manuscript claims:

- `model_comparison_repeated.json`
- `concurrency_tail_latency_report.json`
- `dual_judge_expanded_eval.json`
- `turboquant_e2e_quality_ablation.json`
- `niah_depth_expanded.json`
- `pruning_policy_ablation.json`
- `topn_budget_grid_summary.json`

Supporting analyses:

- `quality_failure_cases.md`
- `topn_budget_failure_cases.md`
- `failure_casebook.md`
- `concurrency_repeat_summary.json`
- `cross_device_replication.json`

## Support Material

These are useful, but they are not the current main claim-bearing files:

- `model_comparison.json`
- `niah_report.json`
- `v2_performance_final.json`
- `v2_bench_comparison.json`
- `stress_test_report*.json`
- `turboquant_comparison.json`
- `compression_comparison.json`

These files are now stored physically under `support_runtime/`, with compatibility symlinks left at the folder root.

Related runtime-check artifacts such as:

- `branded_memory_check.json`
- `memory_cross_session_check.json`
- `memory_decay_check.json`

are stored physically under `support_checks/`, again with compatibility symlinks left at the folder root.

## Legacy / Compatibility Files

These come from older paper-side or acceptance-style evaluation lines:

- `step1_acceptance_*`
- `step1_dual_judge_*`
- `ablation_summary.json`
- `formal_intent_verification*.json`
- `referential_intent_audit.json`

Keep them for traceability, but do not treat them as the latest manuscript source of truth by default.
The `step1_*` result files are now stored physically under `legacy_step1/`, with compatibility symlinks left at the folder root.
Other legacy paper-side artifacts such as `ablation_summary.json`, `formal_intent_verification*.json`, and `referential_intent_audit.json` are stored physically under `legacy_misc/`, again with compatibility symlinks left at the folder root.

## Smoke Outputs

These exist to validate runner wiring and checkpoint behavior:

- `*_smoke.json`
- `*_smoke.csv`
- `*_smoke.md`

They are useful for debugging, not for final paper claims.
Smoke files are now stored physically under `smoke/`, with compatibility symlinks left at the folder root.
